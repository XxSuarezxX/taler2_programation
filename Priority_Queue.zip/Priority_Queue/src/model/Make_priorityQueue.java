package model;
import java.util.PriorityQueue;

public class Make_priorityQueue {
    PriorityQueue<Data_Patient>priorityQueue = new PriorityQueue<>();

    public void addPriorityQueue(String name, int severity) {
        Data_Patient patient = new Data_Patient(name, severity);
        priorityQueue.add(patient);
    }

    public PriorityQueue<Data_Patient> getPriorityQueue() {
        return priorityQueue;
    }

}
