package model;

public class Data_Patient implements Comparable<Data_Patient>{

    String name_patient;
    int severity_level;

    public Data_Patient(String name_patient, int severity_level){
        this.name_patient = name_patient;
        this.severity_level = severity_level;
    }
    public Data_Patient() {
    }

    public int compareTo(Data_Patient other) {
        return Integer.compare(other.severity_level, this.severity_level);
    }

    public String getName_patient() {
        return name_patient;
    }

    public int getSeverity_level() {
        return severity_level;
    }
}
