package presenter;
import model.Data_Patient;
import model.Make_priorityQueue;
import view.View;

import java.util.PriorityQueue;

public class Presenter {
    Make_priorityQueue makePriorityQueue = new Make_priorityQueue();
    View view = new View();

    public void run() {
        int option = 0;
        while (option != 3) {
            option = showMenu();
            switch (option) {
                case 1:
                    add_patient();
                    break;
                case 2:
                    show_information();
                    break;
                case 3:
                    exit();
                    break;
            }
        }
    }

    public int showMenu() {
        int option = view.readGraphicInt("PACIENTES." +
                "\n1. Añadir Paciente." +
                "\n2. Ver Lista de prioridades." +
                "\n3. Salir");
        return option;
    }

    public void add_patient() {
        String name_patient = view.readGraphicString("ingresa el nombre del paciente");
        int severity_level = view.readGraphicInt("Ingresa el nivel de gravedad del paciente" +
                "\n del 1 a 5\n" +
                "1. Caso leve \n" +
                "5. Mayor Gravedad");
        if (severity_level > 5) {
            view.readGraphicMessage("dato fuera de aceptacion");
        } else {
            view.readGraphicMessage("paciente almacenado");
            makePriorityQueue.addPriorityQueue(name_patient, severity_level);
        }
    }

    public void show_information() {
        String data_store="";
        PriorityQueue<Data_Patient> priorityData = makePriorityQueue.getPriorityQueue();
        for (Data_Patient data : priorityData){
            data_store += "Nombre: " + data.getName_patient() + "\n";
            data_store += "Prioridad: " + data.getSeverity_level() + "\n";
            data_store += "--------------------\n";
        }
        view.readGraphicMessage(data_store);
    }

    public void exit() {
        System.exit(0);
    }

    public static void main(String[] args) {
        Presenter presenter = new Presenter();
        presenter.run();
    }
}
