package presenter;

import model.Number_hash;
import model.Make_hash;
import view.View;

import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;

public class Presenter {
    Make_hash makeHash = new Make_hash();
    View view = new View();

    public void run() {
        String input = view.readGraphicString("Ingrese el conjunto de números (por ejemplo, {1,2,3,4}): ");
        Set<Integer> numbers = parseNumbers(input);

        for (int num : numbers) {
            Number_hash numberHash = new Number_hash();
            numberHash.setInput_numer(Integer.toString(num));
            makeHash.addNumbers(numberHash);
        }

        makeHash.generatePowerSet();
    }

    public void show_power_set() {
        for (Set<Number_hash> subset : makeHash.getPowerSet()) {
           System.out.print("{ ");
            for (Number_hash numberHash : subset) {
                System.out.print(numberHash.getInput_numer() + " ");
            }
            System.out.println("}");
        }
    }

    private Set<Integer> parseNumbers(String input) {
        Set<Integer> numbers = new HashSet<>();
        StringTokenizer tokenizer = new StringTokenizer(input, "{}, ");
        while (tokenizer.hasMoreTokens()) {
            String token = tokenizer.nextToken();
            if (!token.isEmpty()) {
                try {
                    int num = Integer.parseInt(token);
                    numbers.add(num);
                } catch (NumberFormatException e) {
                    // Ignorar elementos no numéricos
                }
            }
        }
        return numbers;
    }

    public static void main(String[] args) {
        Presenter presenter = new Presenter();
        presenter.run();
        presenter.show_power_set();
    }
}
