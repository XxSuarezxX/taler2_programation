package model;

public class Number_hash {

    String input_numer;


    public Number_hash() {
    }

    public void setInput_numer(String input_numer) {
        this.input_numer = input_numer;
    }

    public String getInput_numer() {
        return input_numer;
    }
}
