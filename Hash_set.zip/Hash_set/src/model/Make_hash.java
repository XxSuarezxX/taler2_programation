package model;

import java.util.HashSet;
import java.util.Set;

public class Make_hash {
    HashSet<Number_hash> hashNumbers = new HashSet<>();
    Set<Set<Number_hash>> powerSet = new HashSet<>();

    public void addNumbers(Number_hash numberHash){
        hashNumbers.add(numberHash);
    }

    public HashSet<Number_hash> getHashNumbers() {
        return hashNumbers;
    }

    public void generatePowerSet(){
        int n = hashNumbers.size();

        for (int i = 0; i < (1 << n); i++) {
            Set<Number_hash> subset = new HashSet<>();
            int j = 0;
            for (Number_hash numberHash : hashNumbers) {
                if ((i & (1 << j)) > 0) {
                    subset.add(numberHash);
                }
                j++;
            }
            powerSet.add(subset);
        }
    }

    public Set<Set<Number_hash>> getPowerSet() {
        return powerSet;
    }
}
