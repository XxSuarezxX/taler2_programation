package presenter;

import model.ExpressionEvaluator;
import view.View;

public class Presenter {
    ExpressionEvaluator evaluator = new ExpressionEvaluator();
    View view = new View();

    public void run() {
        boolean continuar = true;

        while (continuar) {
            String operation = view.readGraphicString("Ingrese la operación (o escriba 'salir' para detenerse)");

            if (operation.equalsIgnoreCase("salir")) {
                continuar = false;
            } else {
                double result = evaluator.evaluateExpression(operation);

                view.displayResult(operation, result);

            }
        }

    }

    public static void main(String[] args) {
        Presenter presenter = new Presenter();
        presenter.run();
    }
}
