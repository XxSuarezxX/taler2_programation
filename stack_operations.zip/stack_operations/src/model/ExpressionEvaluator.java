package model;

import java.util.Stack;

public class ExpressionEvaluator {
    public double evaluateExpression(String expression) {
        String[] tokens = expression.split("\\s+");
        Stack<Double> values = new Stack<>();
        Stack<String> operators = new Stack<>();

        for (String token : tokens) {
            if (isNumber(token)) {
                values.push(Double.parseDouble(token));
            } else if (isOperator(token)) {
                while (!operators.isEmpty() && !operators.peek().equals("(") && hasHigherPrecedence(operators.peek(), token)) {
                    applyPendingOperation(values, operators);
                }
                operators.push(token);
            } else if (isFunction(token)) {
                operators.push(token);
            } else if (token.equals("(")) {
                operators.push(token);
            } else if (token.equals(")")) {
                while (!operators.peek().equals("(")) {
                    applyPendingOperation(values, operators);
                }
                operators.pop(); 
                if (!operators.isEmpty() && isFunction(operators.peek())) {
                    applyPendingOperation(values, operators);
                }
            }
        }

        while (!operators.isEmpty()) {
            applyPendingOperation(values, operators);
        }

        return values.pop();
    }

    private boolean isNumber(String token) {
        return token.matches("-?\\d+(\\.\\d+)?");
    }

    private boolean isOperator(String token) {
        return token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/");
    }

    private boolean isFunction(String token) {
        return token.matches("sin|cos|tan");
    }

    private boolean hasHigherPrecedence(String op1, String op2) {
        int precedence1 = getPrecedence(op1);
        int precedence2 = getPrecedence(op2);
        return precedence1 >= precedence2;
    }

    private int getPrecedence(String operator) {
        if (operator.equals("+") || operator.equals("-")) {
            return 1;
        } else if (operator.equals("*") || operator.equals("/")) {
            return 2;
        } else if (isFunction(operator)) {
            return 3;
        }
        return 0;
    }

    private void applyPendingOperation(Stack<Double> values, Stack<String> operators) {
        if (!operators.isEmpty() && !operators.peek().equals("(")) {
            String operator = operators.pop(); // Pop the operator from the stack
            if (isFunction(operator)) {
                if (values.isEmpty()) {
                    throw new IllegalArgumentException("Expresión inválida: faltan operandos para la función " + operator);
                }
                double value = values.pop();
                values.push(applyFunction(operator, value));
            } else {
                if (values.size() < 2) { // Check if there are at least two values in the stack
                    throw new IllegalArgumentException("Expresión inválida: faltan operandos para el operador " + operator);
                }
                double b = values.pop();
                double a = values.pop();
                values.push(applyOperator(a, b, operator));
            }
        }
    }


    private double applyFunction(String function, double value) {
        switch (function) {
            case "sin":
                return Math.sin(value);
            case "cos":
                return Math.cos(value);
            case "tan":
                return Math.tan(value);
            default:
                throw new IllegalArgumentException("Función no válida: " + function);
        }
    }

    private double applyOperator(double a, double b, String operator) {
        switch (operator) {
            case "+":
                return a + b;
            case "-":
                return a - b;
            case "*":
                return a * b;
            case "/":
                return a / b;
            default:
                throw new IllegalArgumentException("Operador no válido: " + operator);
        }
    }
}
