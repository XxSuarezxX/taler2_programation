package model;

public class Input_operation {
    private String operation;

    public Input_operation(String operation) {
        this.operation = operation;
    }

    public Input_operation() {
    }

    public String getOperation() {
        return operation;
    }
}
