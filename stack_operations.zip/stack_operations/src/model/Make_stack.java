package model;

import java.util.Stack;

public class Make_stack {
    Stack<Input_operation> stackOperation = new Stack<>();

    public void addStack(Input_operation operation) {
        stackOperation.add(operation);
    }

    public Stack<Input_operation> getStackOperation() {
        return stackOperation;
    }
}
