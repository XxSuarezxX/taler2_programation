package model;

import java.util.LinkedList;

public class Make_Linked {

    LinkedList<Set_data> linked_setData = new LinkedList<>();

    public void addTasks(Set_data taskData) {
        linked_setData.add(taskData);
    }

    public LinkedList<Set_data> getLinked_setData() {
        return linked_setData;
    }
}
