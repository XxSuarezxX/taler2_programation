package model;
import java.util.LinkedList;

public class Set_data {
    String name;
    String expiration_date;
    String description;
    int time_completly;


    public Set_data(String name, String description, String expiration_date, int time_completly) {
        this.name = name;
        this.expiration_date = expiration_date;
        this.description = description;
        this.time_completly = time_completly;
    }

    public Set_data() {
    }

    public String getName() {
        return name;
    }

    public String getExpiration_date() {
        return expiration_date;
    }

    public String getDescription() {
        return description;
    }

    public int getTime_completly() {
        return time_completly;
    }
}