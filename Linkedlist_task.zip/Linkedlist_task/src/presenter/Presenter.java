package presenter;
import model.Set_data;
import model.Make_Linked;
import view.View;

import java.util.LinkedList;

public class Presenter {
    Set_data setData = new Set_data();
    Make_Linked makeLinked = new Make_Linked();
    View view = new View();

    public void run(){
        int option =0;
        while (option !=4){
            option = showMenu();
            switch (option){
                case 1:
                    add();
                    break;
                case 2:
                    show_adds();
                    break;
                case 3:
                    show_person();
                    break;
                case 4:
                    exit();
                    break;
            }
            run();
        }
    }

    public int showMenu(){
        int option = view.readGraphicInt("1.Ingresar"+
                "\n2.mostrar datos" + "\n3. mostrar datos por persona" +  "\n4" +
                ". salir");
        return option;
    }

    public void add(){
        String name_user = view.readGraphicString("ingrese el nombre del usuario.");
        int num_amount = view.readGraphicInt("ingrese el numero de tareas a desarrollar");
        for(int i=0; i<num_amount; i++){
            String description = view.readGraphicString("ingrese la descripcion de la tarea" );
            String expiration_date = view.readGraphicString("ingrese la fecha en este formato ----");
            int time_completly = view.readGraphicInt("ingrese el tiempo de completado (MIN)");
            Set_data taskData = new Set_data(name_user, description, expiration_date, time_completly);
            makeLinked.addTasks(taskData);
        }
    }

    public void show_adds() {
        String data_store = "";
        LinkedList<Set_data> linked_data = makeLinked.getLinked_setData();
        String currentUser = "";

        for (Set_data task : linked_data) {
            if (!task.getName().equals(currentUser)) {
                currentUser = task.getName();
                data_store += "";
                data_store += "NOMBRE USUARIO: " + currentUser + "\n";
                data_store += "-----------------------\n";
            }
            data_store += "descripcion tarea: " + task.getDescription() + "\n";
            data_store += "fecha caduca: " + task.getExpiration_date() + "\n";
            data_store += "tiempo completado: " + task.getTime_completly() + "\n";
            data_store += "-----------------------------------\n";
        }

        view.readGraphicMessage(data_store);
    }

    public void show_person() {
        LinkedList<Set_data> linked_search = makeLinked.getLinked_setData();
        String data_store = "";
        String name_user = view.readGraphicString("Ingrese el nombre del usuario al que desea ver.");
        boolean userFound = false;
        for (Set_data linked_pivot : linked_search) {
            if (name_user.equals(linked_pivot.getName())) {
                if (!userFound) {
                    data_store += "NOMBRE DE USUARIO: " + linked_pivot.getName() + "\n";
                    userFound = true;
                }
                data_store += "Descripcion: " + linked_pivot.getDescription() + "\n";
                data_store += "Fecha Caduca: " + linked_pivot.getExpiration_date() + "\n";
                data_store += "Tiempo Completado: " + linked_pivot.getTime_completly() + "\n";
                data_store += "-----------------------------------\n";
            }
        }
        if (!userFound) {
            view.readGraphicMessage("Nombre de usuario no encontrado");
        } else {
            view.readGraphicMessage(data_store);
        }
    }


    public void exit(){
        System.exit(0);
    }



    public static void main(String[] args) {
        Presenter presenter = new Presenter();
        presenter.run();;
    }
}
