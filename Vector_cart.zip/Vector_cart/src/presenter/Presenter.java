package presenter;
import model.Dates_cart;
import model.Make_vector;
import view.View;

public class Presenter {
    Make_vector makeVector = new Make_vector();
    View view = new View();

    public void run(){
        int option =0;
        while (option != 4){
            option = showMenu();
            switch (option){
                case 1:
                    add_Products();
                    break;
                case 2:
                    show_information();
                    break;
                case 3:
                    exit();
                    break;
            }
            run();
        }
    }

    public int showMenu(){
        int option = view.readGraphicInt("CARRITO DE COMPRAS" +
                "\n1. Insertar" +
                "\n2. Ver Informacion" +
                "\n3. Salir");
        return option;
    }

    public void add_Products(){
        String name_product = view.readGraphicString("ingrese el nombre del producto");
        int price_product = view.readGraphicInt("ingrese el precio del producto");

        Dates_cart datesCart1 = new Dates_cart(name_product, price_product);
        makeVector.addProduct(datesCart1.getName_product(), datesCart1.getPrice_product());
    }

    public void show_information(){
        String data_store = "";
        int total_sum=0;
        Dates_cart[]vector = makeVector.getVector();
        for (Dates_cart product : vector){
            if (product != null){
                total_sum += product.getPrice_product();
                data_store += "Nombre: " + product.getName_product() + "\n";
                data_store += "Precio: " + product.getPrice_product() + "\n";
                data_store += "----------------- \n";
            }
        }
        data_store += "Total:" + total_sum;
        view.readGraphicMessage(data_store);
    }

    public void exit(){
        System.exit(0);
    }

    public static void main(String[] args) {
        Presenter presenter = new Presenter();
        presenter.run();
    }
}
