package model;

public class Make_vector {
    Dates_cart[]vector = new Dates_cart[200];
    int size=0;

    public void addProduct(String productName, int price) {
        if (size < vector.length) {
            vector[size] = new Dates_cart(productName, price);
            size++;
        }
    }
    public Dates_cart[]getVector(){
        return vector;
    }
}
