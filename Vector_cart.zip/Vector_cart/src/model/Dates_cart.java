package model;

public class Dates_cart {

    String name_product;
    int price_product;

    public Dates_cart(String name_product, int price_product){
        this.name_product = name_product;
        this.price_product = price_product;
    }

    public Dates_cart() {

    }

    public String getName_product() {
        return name_product;
    }

    public int getPrice_product() {
        return price_product;
    }
}
